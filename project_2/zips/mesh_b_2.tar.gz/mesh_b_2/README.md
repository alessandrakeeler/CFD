Nu: 0.0009
Delta T: 0.0033
Reynolds: 110 