Nu: 0.005 
Reynolds: 20 
Delta T: 0.005